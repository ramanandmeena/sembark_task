@extends('admin.layouts.index')
@section('title', 'Dashboard')
@section('pageheader')
 <!-- Content Header (Page header) -->
 <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Profile</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">Profile</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
@endsection
@section('content')  
<!-- Main content -->
 <!-- Main content -->
 <section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <!-- Profile Image -->
                <div class="card card-primary">
                    <div class="card-body box-profile">
                        <div class="text-center position-relative">
                            <img class="profile-user-img img-fluid img-circle"
                                 id="profile-preview"
                                 src="{{ asset('uploads/adminprofiles/' . ($admin->profile_image ?? 'defult.png')) }}"
                                 alt="User profile picture">
                            <button type="button" class="btn btn-sm btn-light position-absolute top-0 end-0"
                                    id="edit-image-btn" style="border-radius: 50%;">
                                <i class="fas fa-edit"></i>
                            </button>
                        </div>
                        <h3 class="profile-username text-center">{{$admin->name}}</h3>
                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
            <!-- /.col -->
            <div class="col-md-7">
                <div class="card">
                    <div class="card-body">
                        <form class="form-horizontal" action="{{ route('admin.profile.update') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group row">
                                <label for="inputName" class="col-sm-2 col-form-label">Name</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="name" name="name" value="{{$admin->name}}">
                                </div>
                            </div>
                            
                            <div class="form-group row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
                                <div class="col-sm-10">
                                    <input type="password" class="form-control" id="password" name="password">
                                    <span>Leave this field blank to keep the current password.</span>
                                </div>
                            </div>
                            <div class="form-group row" id="image-upload-section" style="display: none;">
                                <label for="profile-image" class="col-sm-2 col-form-label">Profile Image</label>
                                <div class="col-sm-10">
                                    <input type="file" class="form-control" id="profile-image" name="profile_image" accept="image/*">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="offset-sm-2 col-sm-10">
                                    <button type="submit" class="btn btn-danger">Submit</button>
                                </div>
                            </div>
                        </form>
                        <!-- /.form -->
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</section>
  <!-- /.content -->
  <script>
    document.getElementById('edit-image-btn').addEventListener('click', function () {
        document.getElementById('image-upload-section').style.display = 'block';
    });

    document.getElementById('profile-image').addEventListener('change', function (event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById('profile-preview').src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    });
</script>

@endsection