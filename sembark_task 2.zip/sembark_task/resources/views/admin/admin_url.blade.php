@extends('admin.layouts.index')
@section('title', 'Dashboard')
@section('pageheader')
 <!-- Content Header (Page header) -->
 <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">URLs</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">URLs</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
@endsection
@section('content')  
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <!-- Card Header -->
          <div class="card-header">
            <div class="row w-100 m-0 p-0">
              <div class="col-6 d-flex align-items-center ">
                 <p>URLs list</p>
              </div>
               <div class="col-6 d-flex justify-content-end align-items-center">
              <select id="monthFilter" class="form-control mr-2" style="width:180px;">
                <option value="">Filter By Month</option>
                <option value="01">January</option>
                <option value="02">February</option>
                <option value="03">March</option>
                <option value="04">April</option>
                <option value="05">May</option>
                <option value="06">June</option>
                <option value="07">July</option>
                <option value="08">August</option>
                <option value="09">September</option>
                <option value="10">October</option>
                <option value="11">November</option>
                <option value="12">December</option>
            </select>
            </div>
            </div>
          </div>
          <!-- Card Body -->
          <div class="card-body">
            <table id="table2" class="table table-bordered table-hover">
              <thead>
                <tr>
                  <th>Sr No</th>
                  <th>Short URL</th>
                  <th>Long URL</th>
                  <th>Hits</th>
                  <th>User</th>
                  <th>Created On</th>
                </tr>
              </thead>
              <tbody>
               
         @foreach($urls as $url)
          <tr>
            <td>{{ $loop->index+1 }}</td>
            <td>{{ url($url->short_url) }}</td>
            <td>{{ $url->long_url }}</td>
            <td>{{ $url->hit }}</td>
            <td>{{ $url->admin->name ?? 'N/A' }}</td>
           <td>{{ $url->created_at->format('d M Y, h:i A') }}</td>
          </tr>
          @endforeach
      
              </tbody>
            </table>
          </div>

        </div>

      </div>
    </div>
  </div>
</section>
@endsection