<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin | @yield('title', 'Default Admin')</title>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="{{ asset('admin/plugins/fontawesome-free/css/all.min.css') }}">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="{{ asset('admin/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css') }}">
  <!-- iCheck -->
  <link rel="stylesheet" href="{{ asset('admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css') }}">
  <!-- JQVMap -->
  <link rel="stylesheet" href="{{ asset('admin/plugins/jqvmap/jqvmap.min.css') }}">
  <!-- Theme style -->
  <link rel="stylesheet" href="{{ asset('admin/dist/css/adminlte.min.css') }}">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="{{ asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css') }}">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="{{ asset('admin/plugins/daterangepicker/daterangepicker.css') }}">
  <!-- summernote -->
  <link rel="stylesheet" href="{{ asset('admin/plugins/summernote/summernote-bs4.min.css') }}">
  <link rel="stylesheet" href="{{ asset('admin/plugins/toastr/toastr.css') }}">
  <link rel="stylesheet" href="{{ asset('admin/plugins/toastr/toastr.min.css') }}">
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="{{ asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css') }}">

  <!-- DataTables -->
  <link rel="stylesheet" href="{{ asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css') }}">
  <link rel="stylesheet" href="{{ asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css') }}">
  <link rel="stylesheet" href="{{ asset('admin/plugins/datatables-buttons/css/buttons.bootstrap4.min.css') }}">
</head>
{{-- admin ui work and logic --}}
@php
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Request;
$baseUrl = Request::root();
$admin_ui = DB::table('adminpanel_ui')->first();

  $mode = $admin_ui->mode;
  $copy_right = $admin_ui->copyrigth;
  $full_screen = $admin_ui->full_view;

  if($mode=="dark"){
    $sidebar_class = "sidebar-dark-primary";
    $nav_bar_color = "dark-mode";
    $dark_mode_icon = "fas fa-moon";
    $dark_mode = "dark-mode";
  }
  else{
    $sidebar_class = "sidebar-light-info";
    $dark_mode = " ";
    $dark_mode_icon = "fas fa-sun";
    $nav_bar_color = "bg-white";
  }
  $header_fix = "layout-navbar-fixed";
  $footer_fix = "layout-footer-fixed";
@endphp
<body class="hold-transition sidebar-mini layout-fixed {{$dark_mode}}  {{$header_fix}} {{$footer_fix}}">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light {{$nav_bar_color}}">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <form action="{{ route("admin.darkmode") }}" method="post">
          @csrf
        <a class="nav-link" href="#" role="button">
          <input type="hidden" name="mode" value="{{$mode}}">
         <button type="submit"><i class="{{$dark_mode_icon}}"></i></button>
        </a>
      </form>
      </li>
      <li class="nav-item">
          <a class="nav-link" data-widget="fullscreen" href="#" role="button">
            <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#" style="margin-top: -8px;">
          <!-- Profile image with optimized size -->
          <img src="{{ asset('uploads/adminprofiles/' . (Auth::guard('admin')->user()->profile_image ?? 'defult.png')) }}" class="img-fluid img-circle" style="height: 40px; width: 40px;" alt="User Image">
        </a>
        <!-- Dropdown Menu -->
        <div class="dropdown-menu dropdown-menu-right" style="min-width: 150px;">
          <!-- Profile Link -->
          <a href="{{ route('admin.profile') }}" class="dropdown-item">
            <i class="fas fa-user"></i> Profile
          </a>
          <div class="dropdown-divider"></div>
          <!-- Logout Link -->
          <a href="{{ route('admin.logout') }}" class="dropdown-item">
            <i class="fas fa-sign-out-alt"></i> Logout
          </a>
        </div>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar  {{ $sidebar_class }} elevation-4">
    <!-- Brand Logo -->
    <a href="{{ $baseUrl }}/admin/dashboard" class="brand-link">
      <span class="brand-text">{{ Auth::guard('admin')->user()->name ?? 'Admin' }}</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->


      <!-- SidebarSearch Form -->
      <div class="form-inline mt-3 pb-3 mb-3">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
    <nav class="mt-2">
                
        <!-- Sidebar Menu -->
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false"> 
          @php
            $user = Auth::guard('admin')->user();
              $class = '';
              $name = "Clients";
            if($user->role === 'Member'){
              $class = 'd-none';
              $name = "Users";
            }
            if($user->role === 'Admin'){
              $name = "Users";
            }
          @endphp             
                <li class="nav-item {{ $class }}">
                    <a href="{{route('admin.clients')}}" class="nav-link {{ Request::routeIs('admin.clients') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-users"></i>
                        <p>{{$name}}</p>
                    </a>
                </li>
           
                        
                <li class="nav-item ">
                    <a href="{{route('admin.url_list')}}" class="nav-link {{ Request::routeIs('admin.url_list') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-link"></i>
                        <p>Urls</p>
                    </a>
                  
                </li>
                    </ul>
        
      </nav>
    </div>
  </aside>
  <div class="content-wrapper">
   

      @yield('pageheader')
      @yield('content')

  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; {{ \Carbon\Carbon::now()->format('Y') }} {{ $copy_right }}</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      {{-- <b>Version</b> 3.2.0 --}}
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="{{ asset('admin/plugins/jquery/jquery.min.js') }}"></script>
<!-- jQuery UI 1.11.4 -->
<script src="{{ asset('admin/plugins/jquery-ui/jquery-ui.min.js') }}"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="{{ asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<!-- ChartJS -->
<script src="{{ asset('admin/plugins/chart.js/Chart.min.js') }}"></script>
<!-- Sparkline -->
<script src="{{ asset('admin/plugins/sparklines/sparkline.js') }}"></script>

<!-- jQuery Knob Chart -->
<script src="{{ asset('admin/plugins/jquery-knob/jquery.knob.min.js') }}"></script>
<!-- daterangepicker -->
<script src="{{ asset('admin/plugins/moment/moment.min.js') }}"></script>
<script src="{{ asset('admin/plugins/daterangepicker/daterangepicker.js') }}"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="{{ asset('admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js') }}"></script>
<!-- Summernote -->
<script src="{{ asset('admin/plugins/summernote/summernote-bs4.min.js') }}"></script>
<!-- overlayScrollbars -->
<script src="{{ asset('admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js') }}"></script>
<!-- AdminLTE App -->
<script src="{{ asset('admin/dist/js/adminlte.js') }}"></script>



<script src="{{ asset('admin/plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
<script src="{{ asset('admin/plugins/datatables-buttons/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ asset('admin/plugins/datatables-buttons/js/buttons.bootstrap4.min.js') }}"></script>
<script src="{{ asset('admin/plugins/datatables-buttons/js/buttons.html5.min.js') }}"></script>
<script src="{{ asset('admin/plugins/datatables-buttons/js/buttons.print.min.js') }}"></script>
<script src="{{ asset('admin/plugins/datatables-buttons/js/buttons.colVis.min.js') }}"></script>

<script src="{{ asset('admin/dist/js/pages/dashboard.js') }}"></script>
<script src="{{ asset('admin/plugins/toastr/toastr.min.js') }}"></script>
  <script type="text/javascript">
    @if (session('tstatus'))
        toastr.success("{{ session('tstatus') }}");  // Show success message in toast
    @endif
    @if (session('testatus'))
        toastr.error("{{ session('testatus') }}");  // Show success message in toast
    @endif
  </script>
  <!-- SweetAlert2 -->
<script src="{{ asset('admin/plugins/sweetalert2/sweetalert2.min.js')}}"></script>
<script type="text/javascript">
@if (session('sweetstatus'))
    $(document).ready(function() {
      Swal.fire({
        position: 'top-end', // Position of the Toast (top-right)
        icon: 'success', // Type of icon to show (success, error, etc.)
        title: "{{ session('sweetstatus') }}", // Display the message from the session
        showConfirmButton: false, // Don't show the 'OK' button
        timer: 3000, // Auto-close after 3 seconds
        toast: true, // Enable Toast style
      });
    });
  @endif
  @if (session('sweetstatuserror'))
    $(document).ready(function() {
      Swal.fire({
        position: 'top-end', // Position of the Toast (top-right)
        icon: 'error', // Type of icon to show (success, error, etc.)
        title: "{{ session('sweetstatuserror') }}", // Display the message from the session
        showConfirmButton: false, // Don't show the 'OK' button
        timer: 3000, // Auto-close after 3 seconds
        toast: true, // Enable Toast style
      });
    });
  @endif
</script>
<!-- <script>
$(document).ready(function() {
    $('#myTable').DataTable({
        dom: 'Bfrtip',
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
    });
});
</script> -->

<script>
$(document).ready(function() {

    // Universal Function for Month Filter
    function applyMonthFilter(tableId, createdOnIndex) {

        var table = $(tableId).DataTable({
            dom: 'Bfrtip',
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        });

        // Add Month Filter Logic
        $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {

            // Only run filter on the specific table
            if (settings.sTableId !== tableId.replace('#', '')) return true;

            var selectedMonth = $('#monthFilter').val();
            var createdAt = data[createdOnIndex]; // Different index for each table

            if (!selectedMonth) return true;

            var monthFromTable = moment(createdAt, "DD MMM YYYY, hh:mm A").format("MM");

            return monthFromTable === selectedMonth;
        });

        // Dropdown Change Event
        $('#monthFilter').change(function() {
            table.draw();
        });
    }

    
    applyMonthFilter('#table1', 6); 
    applyMonthFilter('#table2', 5); 
    applyMonthFilter('#table3', 4); 
});
</script>



<!-- JQVMap -->
{{-- <script src="{{ asset('admin/plugins/jqvmap/jquery.vmap.min.js') }}"></script>
<script src="{{ asset('admin/plugins/jqvmap/maps/jquery.vmap.usa.js') }}"></script> --}}
<!-- AdminLTE for demo purposes -->
{{-- <script src="{{ asset('admin/dist/js/demo.js') }}"></script> --}}
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->


</body>
</html>
