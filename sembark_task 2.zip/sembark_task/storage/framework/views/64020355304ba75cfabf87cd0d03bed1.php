<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('pageheader'); ?>
 <!-- Content Header (Page header) -->
 <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">URLs</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">URLs</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <!-- Card Header -->
          <div class="card-header">
            <div class="row w-100 m-0 p-0">
              <div class="col-6 d-flex align-items-center ">
                 <p>URLs list</p>
              </div>
               <div class="col-6 d-flex justify-content-end align-items-center">
              <select id="monthFilter" class="form-control mr-2" style="width:180px;">
                <option value="">Filter By Month</option>
                <option value="01">January</option>
                <option value="02">February</option>
                <option value="03">March</option>
                <option value="04">April</option>
                <option value="05">May</option>
                <option value="06">June</option>
                <option value="07">July</option>
                <option value="08">August</option>
                <option value="09">September</option>
                <option value="10">October</option>
                <option value="11">November</option>
                <option value="12">December</option>
            </select>
            </div>
            </div>
          </div>
          <!-- Card Body -->
          <div class="card-body">
            <table id="table2" class="table table-bordered table-hover">
              <thead>
                <tr>
                  <th>Sr No</th>
                  <th>Short URL</th>
                  <th>Long URL</th>
                  <th>Hits</th>
                  <th>User</th>
                  <th>Created On</th>
                </tr>
              </thead>
              <tbody>
               
         <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->index+1); ?></td>
            <td><?php echo e(url($url->short_url)); ?></td>
            <td><?php echo e($url->long_url); ?></td>
            <td><?php echo e($url->hit); ?></td>
            <td><?php echo e($url->admin->name ?? 'N/A'); ?></td>
           <td><?php echo e($url->created_at->format('d M Y, h:i A')); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
              </tbody>
            </table>
          </div>

        </div>

      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ramanandmeena/Downloads/sembark_task/resources/views/admin/admin_url.blade.php ENDPATH**/ ?>