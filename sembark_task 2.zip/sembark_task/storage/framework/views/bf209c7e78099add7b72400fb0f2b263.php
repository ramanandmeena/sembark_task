<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('pageheader'); ?>
 <!-- Content Header (Page header) -->
 <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">URLs</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">URLs</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">

        <div class="card">

          <!-- Card Header -->
          <div class="card-header">
            <div class="row w-100 m-0 p-0">
              
              <!-- Title Left -->
               <?php
                $user = Auth::guard('admin')->user();
               ?>
              <div class="col-6 d-flex align-items-center ">
                 <a href="<?php echo e(route('admin.admin_url_list')); ?>"><button class="btn btn-success <?php echo e($user->role === 'Member' ? 'd-none' : ''); ?>" data-toggle="modal" data-target="#inviteModal">
                  <i class="fas fa-eye"></i> View all
                  </button></a>
              </div>

              <!-- Button Right -->
              <div class="col-6 d-flex justify-content-end align-items-center">
                 <select id="monthFilter" class="form-control mr-2" style="width:180px;">
                <option value="">Filter By Month</option>
                <option value="01">January</option>
                <option value="02">February</option>
                <option value="03">March</option>
                <option value="04">April</option>
                <option value="05">May</option>
                <option value="06">June</option>
                <option value="07">July</option>
                <option value="08">August</option>
                <option value="09">September</option>
                <option value="10">October</option>
                <option value="11">November</option>
                <option value="12">December</option>
            </select>
            
                <button class="btn btn-success" data-toggle="modal" data-target="#inviteModal">
                  <i class="fas fa-user-plus"></i> Generate
                </button>
              </div>

            </div>
          </div>

          <!-- Card Body -->
          <div class="card-body">
            <table id="table3" class="table table-bordered table-hover">
              <thead>
                <tr>
                  <th>Sr No</th>
                  <th>Short URL</th>
                  <th>Long URL</th>
                  <th>Hits</th>
                
                  <th>Created On</th>
                </tr>
              </thead>
              <tbody>
               
            <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->index+1); ?></td>
            <td><?php echo e(url($url->short_url)); ?></td>
            <td><?php echo e($url->long_url); ?></td>
            <td><?php echo e($url->hit); ?></td>
            <td><?php echo e($url->created_at->format('d M Y')); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
              </tbody>
            </table>
          </div>

        </div>

      </div>
    </div>
  </div>
</section>



<!-- ====================== INVITE MODAL ===================== -->
<div class="modal fade" id="inviteModal">
    <div class="modal-dialog">
        <form action="<?php echo e(route('admin.url.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Generate Short URL</h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>

                <div class="modal-body">

                    <div class="form-group">
                        <label>URL</label>
                        <input type="text" name="url"
                               value="<?php echo e(old('url')); ?>"
                               class="form-control <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Enter URL">

                        <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        Close
                    </button>

                    <button type="submit" class="btn btn-success">
                        Generate
                    </button>
                </div>

            </div>
        </form>
    </div>
</div>
  <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ramanandmeena/Downloads/sembark_task/resources/views/admin/urls.blade.php ENDPATH**/ ?>