
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('pageheader'); ?>
 <!-- Content Header (Page header) -->
 <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Dashboard</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">Dashboard</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
<!-- Main content -->
<section class="content">
    <div class="container-fluid text-center">
      <h1>Welcome</h1>
      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
  </section>
  <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ramanandmeena/Downloads/sembark_task/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>