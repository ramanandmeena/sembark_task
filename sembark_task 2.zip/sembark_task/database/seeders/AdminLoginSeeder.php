<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class AdminLoginSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Super Admin
        DB::table('admin_login')->insert([
            'name' => 'admin',
            'username' => 'superadmin',
            'password' => Hash::make('admin123'),
            'profile_image' => null,
            'role' => 'Super Admin',
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Admins
        $admins = [
            [
                'name' => 'test One',
                'username' => 'test1',
                'password' => Hash::make('test123'),
                'profile_image' => null,
                'role' => 'Admin',
                'status' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        DB::table('admin_login')->insert($admins);
    }
}
