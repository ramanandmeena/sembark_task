<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('admin_side_menus', function (Blueprint $table) {
            $table->id();
            $table->string('name');          // Menu name, like 'Dashboard'
            $table->string('icon');          // Icon for the menu item (e.g., 'fas fa-tachometer-alt')
            $table->string('route_name');    // Route name or URL for the menu item
            $table->unsignedBigInteger('parent_id')->nullable();  // For sub-menu, to track parent
            $table->boolean('is_active')->default(true);           // To mark if the menu is active
            $table->timestamps();
        });
        
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('admin_side_menus');
    }
};
