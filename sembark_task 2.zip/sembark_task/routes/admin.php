<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AdminPanelController;

Route::prefix('admin')->group(function () {
    Route::middleware('admin.guest')->group(function () {
    Route::get('login', function () { return view('admin.login');})->name('admin.login');
    Route::Post('login_post', [AdminPanelController::class, 'login_post'])->name('admin.login_post');
    });
    Route::middleware(['auth:admin'])->group(function () {
    Route::get('dashboard', function () { return view('admin.dashboard');})->name('admin.dashboard');
    Route::get('users', function () { return view('admin.dashboard');})->name('admin.users');
    Route::post('darkmode', [AdminPanelController::class, 'darkmode'])->name('admin.darkmode');
    Route::get('logout', [AdminPanelController::class, 'logout'])->name('admin.logout');
    Route::get('profile', [AdminPanelController::class, 'profile'])->name('admin.profile');
    Route::post('update', [AdminPanelController::class, 'updateProfile'])->name('admin.profile.update');
    Route::post('add_client', [AdminPanelController::class, 'add_client'])->name('admin.add_client');
    Route::get('get-clients', [AdminPanelController::class, 'clients'])->name('admin.clients');
    Route::get('url-list', [AdminPanelController::class, 'urls'])->name('admin.url_list');
    Route::post('url_store', [AdminPanelController::class, 'url_store'])->name('admin.url.store');
    Route::get('admin_url_list', [AdminPanelController::class, 'admin_url_list'])->name('admin.admin_url_list');
    

    });
});
Route::get('/{shortUrl}', [AdminPanelController::class, 'redirectShortUrl']);
