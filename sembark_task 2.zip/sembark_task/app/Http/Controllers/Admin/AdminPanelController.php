<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Admin; 
use App\Models\Url;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Redirect;

class AdminPanelController extends Controller
{
    public function darkmode(Request $request)
    {
        $admin_ui = DB::table('adminpanel_ui')->first();
        if ($admin_ui) {
            $newMode = ($admin_ui->mode == 'dark') ? 'light' : 'dark';
            DB::table('adminpanel_ui')->update(['mode' => $newMode]);
            return redirect()->back()->with('sweetstatus', 'The mode has been successfully updated to ' . $newMode . ' mode.');

        }
        return redirect()->back()->with('sweetstatuserror', 'No settings found to update.');
    }

    public function login_post(Request $request)
    {

        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        if (Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password])) {
            
            return redirect()->route('admin.dashboard')->with('sweetstatus', 'Welcome back! You have successfully logged in');
        }
        return redirect()->back()->withErrors(['error' => 'Invalid email or password!']);
    }

    public function logout(Request $request)
    {
        Auth::guard('admin')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('admin.login')->with('success', 'You have logged out successfully.');
    }

    public function profile()
    {
        $admin = Auth::guard('admin')->user();
        return view('admin.profile', compact('admin'));
    }

    public function updateProfile(Request $request)
    {
     try {
        $admin = Auth::guard('admin')->user();
    
        $request->validate([
            'name' => 'required|string|max:255',
            'profile_image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'password' => 'nullable|string|min:6',
        ]);
    
        if ($request->hasFile('profile_image')) {
            if (!empty($admin->profile_image) && file_exists(public_path('uploads/adminprofiles/' . $admin->profile_image))) {
                unlink(public_path('uploads/adminprofiles/' . $admin->profile_image));
            }
    
            // Upload the new profile image
            $file = $request->file('profile_image');
            $filename = time() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('uploads/adminprofiles'), $filename);
            $admin->profile_image = $filename;
        }
    
        // Update the name and username
        $admin->name = $request->name;

    
        // Update the password if provided
        if ($request->filled('password')) {
            $admin->password = bcrypt($request->password);
        }
    
        // Save the updated details
        $admin->save();
    
        return redirect()->back()->with('sweetstatus', 'Profile updated successfully.');
      } catch (\Exception $e) {
        Log::error('Profile update error: ' . $e->getMessage());
        return redirect()->back()->with('error', 'An error occurred. Please try again.');
      }
    }

    public function clients()
    {
    if ($redirect = $this->checkAdminAccess()) {
     return $redirect;
    }
    
      $adminId = Auth::guard('admin')->id();
  
      if (Auth::guard('admin')->user()->role != 'Super Admin') {
          $admins = Admin::where('parent_id', $adminId)
              ->withCount([
                  'urls as generated_urls_count',
                  'childUsers',
              ])
              ->withSum('urls as total_hits_sum', 'hit')
              ->get();
      } else {
          $admins = Admin::where('parent_id', '!=', 0)
              ->withCount([
                  'urls as generated_urls_count',
                  'childUsers',
              ])
              ->withSum('urls as total_hits_sum', 'hit')
              ->get();
      }
    
      return view('admin.clients', compact('admins'));
    }


    public function add_client(Request $request)
    {
        if ($redirect = $this->checkAdminAccess()) {
          return $redirect;
        }
        $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|email|unique:admin_login,email',
            'password' => 'required',
        ]);
        

        $admin = new Admin();
        $admin->name  = $request->name;
        $admin->email = $request->email;
        if(Auth::guard('admin')->user()->role != 'Super Admin'){
             $admin->role = $request->role;
        } 
       
   
        $admin->parent_id = Auth::guard('admin')->id();

        if ($request->filled('password')) {
            $admin->password = bcrypt($request->password);
        }

        $admin->save();

        return back()->with('sweetstatus', 'User invited successfully!');
    }


    public function urls()
    {

        if (Auth::guard('admin')->user()->role == 'Super Admin') {
            return $this->admin_url_list();
        }else{
             $adminId = Auth::guard('admin')->id();
            $urls = Url::where('admin_id', $adminId)->latest()->get();
            return view('admin.urls',compact('urls'));
        }
    }

    public function url_store(Request $request)
    {
        if ($redirect = $this->checkAdminAccess2()) {
            return $redirect; 
        }
            do {
                $shortUrl = Str::random(6);
            } while(Url::where('short_url', $shortUrl)->exists());

            Url::create([
            'long_url' => $request->url,
            'short_url' => $shortUrl,
            'admin_id' => Auth::guard('admin')->id(),
        ]);
        return redirect()->back()->with('tstatus', 'Short URL created successfully!');
    }

    public function redirectShortUrl($shortUrl)
    {
            $url = Url::where('short_url', $shortUrl)->firstOrFail();
            $url->increment('hit');
            return Redirect::to($url->long_url);
    }

    private function checkAdminAccess()
    {
        $user = Auth::guard('admin')->user();
        if (!$user) {
            return redirect()->route('admin.login')->send();
        }
        if ($user->role === 'Member') {
            return redirect()->back()->with('testatus', 'Access Denied!')->send();
        }
        return null; 
    }

    private function checkAdminAccess2()
    {
    $user = Auth::guard('admin')->user();

    if (!$user) {
        return redirect()->route('admin.login');
    }

    // Super Admin aur Member dono ko access deny
    if ($user->role === 'Super Admin') {
        return redirect()->back()->with('testatus', 'Access Denied!');
    }

    return null; // allowed
    }

    public function admin_url_list()
    {
        if ($redirect = $this->checkAdminAccess()) {
          return $redirect;
        }
        if (Auth::guard('admin')->user()->role == 'Super Admin') {
            $urls = Url::with('admin')->latest()->get();
        }
        else{
             $adminId = Auth::guard('admin')->id();
             $childAdminIds = Admin::where('parent_id', $adminId)->pluck('id')->toArray();
             $urls = Url::whereIn('admin_id', $childAdminIds)->with('admin')
                   ->latest()
                   ->get();
        }
        
        return view('admin.admin_url',compact('urls'));
    
    }
}
