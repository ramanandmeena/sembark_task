<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Admin extends Authenticatable
{
    protected $table = 'admin_login';
    protected $fillable = ['name', 'email', 'password', 'role', 'profile_image', 'status', 'parent_id'];
    protected $hidden = ['password', 'remember_token'];

    public function urls()
    {
        return $this->hasMany(\App\Models\Url::class, 'admin_id');
    }

    public function childUsers()
    {
        return $this->hasMany(Admin::class, 'parent_id');
    }
}
